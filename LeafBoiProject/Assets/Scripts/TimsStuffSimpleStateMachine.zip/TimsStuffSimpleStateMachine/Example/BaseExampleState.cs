﻿using UnityEngine;
using System.Collections;

public class BaseExampleState : State
{
    
}
